<?php 
class Text {
public $text;
function Text($_text){
	$this->text = $_text;
}
}
class Message {
public $message;
}	
 ?>
